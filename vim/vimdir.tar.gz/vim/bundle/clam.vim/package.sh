#!/usr/bin/env bash

hg archive ~/Desktop/clam.zip -I 'doc' -I 'plugin' -I 'clamsyntax' -I README.markdown -I LICENSE.markdown
